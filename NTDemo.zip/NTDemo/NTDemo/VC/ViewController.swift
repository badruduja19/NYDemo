//
//  ViewController.swift
//  NTDemo
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//
import Foundation
import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var tv: UITableView!
    
     
    var nyDataModel:NYDataModel = NYDataModel()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.API(done: {(resposeStr:String? ) in
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    func API(done:@escaping (String? ) -> Void)  {
        
        //
        ApiManager.makeHTTPGetRequest(urlStr:Api.getMostviewedList, onCompletion: {(resposeDict:NSDictionary?, err:NSError?) in
            
            
            if err == nil{
                
                DispatchQueue.main.async(){
                    
                    // onCompletion(json, nil)
                    //    semaphore.signal()
                    do{
                        
                        let jsonData = try JSONSerialization.data(withJSONObject: resposeDict ?? [], options: .prettyPrinted)
                        
                        self.nyDataModel = try! JSONDecoder().decode(NYDataModel.self, from:jsonData)
                        
                        
                        self.tv.reloadData()
                        
                        done("success")
                        
                    }catch let error {
                        print(error)
                    }
                    
                }
                
                
            }else{
                
                done("failed")
                
                AppHelper.showAlertControllerWithType(type: .alert, fromController: self, title: AppName, message: err?.localizedDescription, cancelButtonTitle: OK, otherButtonTitle: [], completion:nil)
                
            }
        })
    }


}

extension ViewController:UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.nyDataModel.results?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:NYCell = tableView.dequeueReusableCell(withIdentifier: "NYCell", for: indexPath) as! NYCell
        
        
        let nyDataModel:ResultesDataModel = (self.nyDataModel.results?[indexPath.row] ?? ResultesDataModel()) as! ResultesDataModel
        
        
        cell.lbTitle.text = nyDataModel.title ?? ""
        cell.lbSubTitle.text = nyDataModel.abstract ?? ""
        cell.lbDate.text = nyDataModel.published_date ?? ""
        
        
        
        /*
        let dict = self.apiArr[indexPath.row]
        
        cell.lbTitle.text = dict["title"] as? String
        
        cell.lbSubTitle.text = dict["abstract"] as? String
        
        cell.lbDate.text = dict["published_date"] as? String
        */
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: false)
        
        let DVC:DetailsVC = AppHelper.getStoryBoard().instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        
        DVC.resultDataModel = self.nyDataModel.results?[indexPath.row]
        
        self.navigationController?.pushViewController(DVC, animated: true)
        
    }
    
    
}

