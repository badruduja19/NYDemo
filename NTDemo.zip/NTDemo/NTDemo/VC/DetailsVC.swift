//
//  DetailsVC.swift
//  NTDemo
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class DetailsVC: UIViewController {
    
    @IBOutlet var lblTitle: UILabel!
    
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var tv: UITextView!
    
    
    var resultDataModel:ResultesDataModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // self.resultDataModel = ResultesDataModel()
 
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        self.setValue()
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    

    func setValue()  {
        
        
        
        self.lblTitle.text =  self.resultDataModel.title ?? ""
        
        self.tv.text =  self.resultDataModel.abstract ?? ""
        
        let publishedDate =  self.resultDataModel.published_date ?? ""
        
        self.lblDate.text = "Published Date: " + publishedDate
        
        
    }
    
    
   

}
