//
//  ApiManager.swift
//   
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit
import Foundation

typealias ServiceResponse = (NSDictionary?, NSError?) -> Void


//typealias ServiceResponse = ([[String:Any]]?, NSError?) -> Void

class ApiManager: NSObject {
    
    static let sharedInstance = ApiManager()
    
    
    
    @objc class func makeHTTPPostRequest(path: String, body: [String: AnyObject], fromController:UIViewController, onCompletion: @escaping ServiceResponse) -> Void{
        
        
        let url =   path
        
        print("url = : \(url)")
        
        //Network Checking
        if Reachability.isConnectedToNetwork() == false {
            
            AppHelper.showAlertControllerWithType(type: .alert, fromController: fromController, title: AppName, message: "The Internet connection appears to be offline.", cancelButtonTitle: OK, otherButtonTitle: [], completion:nil)
            
            return
            
        }
        
        SVProgressHUD.show()
        fromController.view.isUserInteractionEnabled = false
        
        
        let requestData:Data = try! JSONSerialization.data(withJSONObject: body, options: []) as Data
        // var err: NSError?
        let urlRequest = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        
        
        // Set the method to POST
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
     //   urlRequest.addValue(requestData.length, forHTTPHeaderField: "Content-Length")
        
        
        // Set the POST body for the request
        urlRequest.httpBody = requestData;
        let session = URLSession.shared
   
        
        let task = session.dataTask(with: urlRequest as URLRequest, completionHandler: {data, response, error -> Void in
            
            DispatchQueue.main.async(){
                SVProgressHUD.dismiss()
                fromController.view.isUserInteractionEnabled = true
            }
            
            
            if error != nil{
                
                DispatchQueue.main.async(){
                    onCompletion(nil, error as NSError?)
                }
                return
            }
          //  print("Response: \(response)")
           // let strData = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
          //  print("Body: \(strData)")
           
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
               
                print("Response Values : \(json)")
                
                DispatchQueue.main.async(){
                    
                   onCompletion(json, nil)
                }
                
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
                DispatchQueue.main.async(){
                    
                   onCompletion(nil, error)
                }
            }
           
        })
        
        task.resume()
    }
    
    @objc class func makeHTTPGetRequest(urlStr: String, onCompletion: @escaping ServiceResponse) -> Void {
       
        let tempUrl = urlStr.addingPercentEncoding(withAllowedCharacters: (NSCharacterSet.urlQueryAllowed))!
        
        print("url = : \(tempUrl)")
        
        let url = URL(string: tempUrl)
        
        
        
        SVProgressHUD.show()
        
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            SVProgressHUD.dismiss()
            
            if error != nil{
                
                DispatchQueue.main.async(){
                    onCompletion(nil, error as NSError?)
                }
                return
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                
                print("Response Values : \(json)")
                
                DispatchQueue.main.async(){
                    
                    onCompletion(json, nil)
                }
                
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
                DispatchQueue.main.async(){
                    
                    onCompletion(nil, error)
                }
            }
            
        }
        
        task.resume()
        
    }
    
    
    
    class func testGetRequest()  {
        
        let url = URL(string: "https://www.okdollar.co/RestService.svc/GetCategoryAndMercNameByMobileNumber?MobileNumber=00959976656084")
        
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            if let data = data {
                do {
                    // Convert the data to JSON
                    let jsonSerialized = try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any]
                    
                    if let json = jsonSerialized, let url = json["url"], let explanation = json["explanation"] {
                        print(url)
                        print(explanation)
                    }
                }  catch let error as NSError {
                    print(error.localizedDescription)
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
    }
}
