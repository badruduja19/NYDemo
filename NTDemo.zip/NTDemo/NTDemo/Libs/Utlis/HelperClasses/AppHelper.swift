//
//  AppHelper.swift
//  
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class AppHelper: NSObject {
    
    var class_sec_sub_jArr = NSArray()
    var sEventDict = NSDictionary()
    @objc  var holidayList = NSMutableArray()
    
    @objc static let sharedInstant = AppHelper()
    
     
    
    
    class func getStoryBoard() -> UIStoryboard {
        
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    
    

    @objc class func showAlertControllerWithType(type:UIAlertController.Style , fromController viewController:UIViewController, title:String, message:String?, cancelButtonTitle:String?, otherButtonTitle:[String]?, completion:((String)-> Void)? = nil )
    {
        
        
        let alertController = UIAlertController(title:title, message:message, preferredStyle: type)
        alertController.addAction(UIAlertAction(title: cancelButtonTitle, style: UIAlertAction.Style.cancel, handler: nil))
        
        if otherButtonTitle != nil {
            
            for title in otherButtonTitle! {
                
                alertController.addAction(UIAlertAction(title: title, style: UIAlertAction.Style.default, handler: {(ACTION :UIAlertAction!)in
                    
                    completion!( ACTION.title!)
                    
                    
                }))
            }
        }
        
        
        
        
        viewController.present(alertController, animated: true, completion: nil)
    }
    
    
    func defaultSave(forKey:String, value:AnyObject) -> Void {
        
        
    }
    
 
    
   
    
    @objc class func convertDateFormat(currentFormat:String, desireFormat:String, dateStr:String) -> String {
        
        let df = DateFormatter.init()
        df.dateFormat = currentFormat
        let date = df.date(from: dateStr)
        
        df.dateFormat = desireFormat
        
        if date == nil {
            return ""
        }
        
        return df.string(from: date!)
    }
    
    
    @objc class func convertStrToDate(currentFormat:String,   dateStr:String) -> Date {
        
        
        let df = DateFormatter.init()
        df.dateFormat = currentFormat
        let date = df.date(from: dateStr)
        
        if date != nil {
            
            return date!
        }
        return Date()
        
    }
    
 
    
    

}
