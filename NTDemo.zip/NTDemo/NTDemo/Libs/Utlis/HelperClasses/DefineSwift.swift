//
//  DefineSwift.swift
//   
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//

import Foundation
import UIKit

let AppName = "NT Demo"
let OK = "OK"
let NO = "NO"
let YES = "YES"

let viewBorderColor = UIColor.lightGray
let btnBtnBorderColor = UIColor.lightGray
let btnCorner:CGFloat = 8.0
let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height

 

var navColor = UIColor.init(red: 255/255.0, green: 218/255.0, blue: 34/255.0, alpha: 1)

 

struct Api {
    
    
    
    static let API_BASE_URL              = "http://api.nytimes.com/svc/mostpopular/v2/"
    static let getMostviewedList  =  API_BASE_URL + "mostviewed/all-sections/7.json?api-key=taL95f2YEoEyfY092c0Mo7aPl43Ou7Np"
    
    
    
    
}

struct Keys {
    static let keyDeviceToken = "keyDeviceToken"
    static let keyUserDetails = "keyUserDetails" 
}

 


