//
//  NYDataModel.swift
//  NTDemo
//
//  Created by Badruduja on 26/03/19.
//  Copyright © 2019 Badruduja. All rights reserved.
//

import UIKit

class NYDataModel: NSObject, Codable {
    
    
    var status:String?
    var copyright:String?
    var num_results:Int?
    
    var results:[ResultesDataModel]?

}
class ResultesDataModel: NSObject, Codable {
    
    var title:String?
    var abstract:String?
    var published_date:String?
    var source:String?
    
     
   }
