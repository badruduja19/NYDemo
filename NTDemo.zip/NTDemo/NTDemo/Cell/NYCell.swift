//
//  NYCell.swift
//  NTDemo
//
//  Created by Badru on 03/25/19.
//  Copyright © 2019 Test. All rights reserved.
//

import UIKit

class NYCell: UITableViewCell {
    
    @IBOutlet weak var iv: UIImageView!
    @IBOutlet weak var lbTitle: UILabel!
    
    @IBOutlet weak var lbSubTitle: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
